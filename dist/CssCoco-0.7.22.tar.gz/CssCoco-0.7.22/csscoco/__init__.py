

def main():
    print('Bla di bla di bla!')