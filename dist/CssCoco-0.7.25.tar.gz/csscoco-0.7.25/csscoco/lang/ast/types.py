

class Type(object):
    pass


class String(Type):
    pass


class Integer(Type):
    pass


class Boolean(Type):
    pass


class NodeType(Type):
    pass


class List(Type):
    pass