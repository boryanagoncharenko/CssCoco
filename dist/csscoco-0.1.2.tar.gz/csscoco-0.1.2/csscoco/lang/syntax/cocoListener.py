# Generated from java-escape by ANTLR 4.4
from antlr4 import *

# This class defines a complete listener for a parse tree produced by cocoParser.
class cocoListener(ParseTreeListener):

    # Enter a parse tree produced by cocoParser#stylesheet.
    def enterStylesheet(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#stylesheet.
    def exitStylesheet(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#convention.
    def enterConvention(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#convention.
    def exitConvention(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#api_call.
    def enterApi_call(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#api_call.
    def exitApi_call(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#list_.
    def enterList_(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#list_.
    def exitList_(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#pattern.
    def enterPattern(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#pattern.
    def exitPattern(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#list_element.
    def enterList_element(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#list_element.
    def exitList_element(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#method_call.
    def enterMethod_call(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#method_call.
    def exitMethod_call(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#declaration.
    def enterDeclaration(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#declaration.
    def exitDeclaration(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#convention_group.
    def enterConvention_group(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#convention_group.
    def exitConvention_group(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#node.
    def enterNode(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#node.
    def exitNode(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#attr_expression.
    def enterAttr_expression(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#attr_expression.
    def exitAttr_expression(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#context.
    def enterContext(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#context.
    def exitContext(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#constraint.
    def enterConstraint(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#constraint.
    def exitConstraint(self, ctx):
        pass


    # Enter a parse tree produced by cocoParser#type_expression.
    def enterType_expression(self, ctx):
        pass

    # Exit a parse tree produced by cocoParser#type_expression.
    def exitType_expression(self, ctx):
        pass


