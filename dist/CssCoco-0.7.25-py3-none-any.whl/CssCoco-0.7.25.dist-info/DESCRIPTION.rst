The package detects violations of CSS code conventions automatically. It contains a number of predefined conventons sets, however, it also comprises a domain-speicific language that is capable of expressing cusomt CSS conventions.


